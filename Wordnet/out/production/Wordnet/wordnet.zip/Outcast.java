
public class Outcast {
    private final WordNet wordnet;
    public Outcast(WordNet wordnet) {
        this.wordnet = wordnet;
    }

    public String outcast(String[] nouns) {
        String outcast = "";
        int maxLength = Integer.MIN_VALUE;
        for (int pointer1 = 0; pointer1 < nouns.length; pointer1++) {
            int distance = 0;
            for (int pointer2 = pointer1 + 1; pointer2 < nouns.length; pointer2++) {
                distance += wordnet.distance(nouns[pointer1],nouns[pointer2]);
            }
            if (distance > maxLength) {
                maxLength = distance;
                outcast = nouns[pointer1];
            }
        }
        return outcast;
    }
}
